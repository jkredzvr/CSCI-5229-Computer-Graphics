# Justin Chin HW 2-3D Scene
CSCI 5229 Computer Graphics

### Application Instructions
#### How to change the view
     
     
* Press m key to cycle through 3 views
    1. view perspective view shows overhead view
    2. perspective first person view on the ground
    3. perspective first person view on the ground (First Person Mode)
* Pressing the arrows changes the pitch and yaw view angle of the 3D scene in view 1 and 2.
* +/-        Changes field of view for perspective during perspective mode
* Press 1 to turn on and off the x,y,z axis
* PgDn/PgUp  Zoom in and out in View 1 and 2
 

#### How to move position and view angle during first person mode
* w : Move fowards
* s : Move backwards
* a : Turn left
* d : Turn right
* Arrow keys - move up and down the point of view angle

#### Exiting the Application
* Press ESC to exit the application

### Estimated time of finishing assignment
- 16 hrs programming
